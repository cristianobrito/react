import logo from './logo.svg';
import './App.css';

function App() {
  return (
    <div className="App">
      <h1>Deu certo</h1>
        <header className="App-header">
        <img src={logo} className="App-logo" alt="logo" />
        <p>
         Tô editando <code>src/App.js </code>OLA REACT parei na aula 35.
        </p>
        <a
          className="App-link"
          href="https://reactjs.org"
          target="_blank"
          rel="noopener noreferrer"
        >
         vamos de aula 35
        </a>
      </header>
    </div>
  );
}

export default App;
