import { render } from '@testing-library/react';
import React from 'react';

class App extends React.Component{
      render(){
        return(
          <div>
              <h1>Ola Mundo do React terminado</h1>
          </div>
        )
      }
  }
export default App;
